package encrypt;

import java.io.File;
import javax.swing.JFileChooser;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.FilenameFilter;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


class filter extends javax.swing.filechooser.FileFilter{
    @Override
    public boolean accept (File obj)
    {
        String extension="";
        extension=obj.getName();
        String ext=extension.substring(extension.lastIndexOf(".")+1,extension.length()).toLowerCase();
        if(ext.length()>0)
        {
               if(ext.equals("gif")||ext.equals("png")||ext.equals("jpg")||ext.equals("jpeg"))
                        return true;
        
        }
        if(obj.isDirectory())
            return true;
        return false;
    }
    @Override
    public String getDescription()
    {
        return "Image Files (*.gif,jgp,png,jpeg)";
    }
}
public class pictureviewer extends javax.swing.JFrame {
    
    JFileChooser jfc=new JFileChooser();
    int widthsize,heightsize;
    File out;
    BufferedImage img=null;
    int width,height;
    int i=0;
    int [][]pixels;
    File[] files;
    protected JLabel jLabel;
    public pictureviewer() {
    initComponents();
    jMenuItem2.setEnabled(false);
    jMenuItem3.setEnabled(false);
    jMenuItem10.setEnabled(false);
    jMenuItem4.setVisible(false);
     jfc.setAcceptAllFileFilterUsed(false);
    jfc.setMultiSelectionEnabled(false);
    jfc.addChoosableFileFilter(new filter());
   
    label1.setText("Preview Not Availale");
    label1.setHorizontalAlignment(JLabel.CENTER);
    jSlider1.setValue(0);
    jSlider1.setMaximum(50);
    jSlider1.setMinimum(-50);
    jSlider1.setPaintTicks(true);
    jSlider1.setMajorTickSpacing(10);
    // jSlider1.setPaintLabels(true);
    jSlider2.setValue(0);
    jSlider2.setMaximum(50);
    jSlider2.setMinimum(-50);
    jSlider2.setPaintTicks(true);
    jSlider2.setMajorTickSpacing(10);
    // jSlider2.setPaintLabels(true);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jToolBar1 = new javax.swing.JToolBar();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        label2 = new javax.swing.JLabel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jToolBar2 = new javax.swing.JToolBar();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        label1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        label3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSlider1 = new javax.swing.JSlider();
        jLabel5 = new javax.swing.JLabel();
        jSlider2 = new javax.swing.JSlider();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();

        jToolBar1.setRollover(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 742, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jTree1.setBackground(new java.awt.Color(255, 255, 204));
        jTree1.setForeground(new java.awt.Color(153, 204, 255));
        jTree1.addTreeExpansionListener(new javax.swing.event.TreeExpansionListener() {
            public void treeExpanded(javax.swing.event.TreeExpansionEvent evt) {
            }
            public void treeCollapsed(javax.swing.event.TreeExpansionEvent evt) {
                jTree1TreeCollapsed(evt);
            }
        });
        jScrollPane2.setViewportView(jTree1);

        jToolBar2.setBackground(new java.awt.Color(255, 255, 204));
        jToolBar2.setRollover(true);

        jLabel3.setText("Tool Bar");
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jToolBar2.add(jLabel3);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 943, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );

        jButton8.setText("jButton8");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton5.setText("SlideShow");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton9.setText("PEN");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton7.setText("Zoom In");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton6.setText("Zoom Out");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Image Viewer");
        setBackground(new java.awt.Color(153, 153, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setFont(new java.awt.Font("Arial Narrow", 2, 14)); // NOI18N
        setForeground(new java.awt.Color(153, 204, 255));

        label1.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setBackground(new java.awt.Color(255, 175, 175));
        jLabel1.setFont(new java.awt.Font("Arial Narrow", 2, 18)); // NOI18N
        jLabel1.setText("                    Preview");

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setForeground(new java.awt.Color(153, 153, 255));

        label3.setBackground(new java.awt.Color(204, 204, 255));
        label3.setForeground(new java.awt.Color(204, 204, 255));
        label3.setDebugGraphicsOptions(javax.swing.DebugGraphics.FLASH_OPTION);
        label3.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                label3MouseWheelMoved(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label3, javax.swing.GroupLayout.DEFAULT_SIZE, 1149, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\rishabh\\Desktop\\left.png")); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\rishabh\\Desktop\\right.png")); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel2.setText("MODIFY");

        jLabel4.setText("BRIGHTNESS");

        jSlider1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jSlider1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jSlider1MouseExited(evt);
            }
        });
        jSlider1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider1StateChanged(evt);
            }
        });

        jLabel5.setText("Contrast");

        jSlider2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jSlider2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider2StateChanged(evt);
            }
        });

        jButton10.setText("Apply");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setText("Reset");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setText("Invert");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setText("Undo");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSlider1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jSlider2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton12)
                            .addComponent(jLabel4))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jButton10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(jButton11)
                .addGap(30, 30, 30))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(jLabel5))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(jLabel2))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(jButton13)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addComponent(jButton12)
                .addGap(37, 37, 37)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jSlider2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton11)
                    .addComponent(jButton10))
                .addGap(19, 19, 19))
        );

        jButton1.setText("Previous");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Next");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jMenuBar1.setBackground(new java.awt.Color(153, 204, 255));

        jMenu1.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Open");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem10.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem10.setText("Rename");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem10);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText("Delete");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Save");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem4.setText("Save As");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuBar1.add(jMenu1);

        jMenu3.setText("Register");

        jMenuItem8.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem8.setText("Login");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem8);

        jMenuItem9.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem9.setText("Register With Us");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem9);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(436, 436, 436)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(587, 587, 587))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton1))
                .addGap(25, 25, 25))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public JLabel getLabel3()
    {
        return label3;
    }

    int newpixel[][];
    int invert=0;
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
    int result=jfc.showOpenDialog(null);
    out=jfc.getSelectedFile();
    
    if(result!=JFileChooser.APPROVE_OPTION)
           {
                out=null;
           }
          else
         {i=1;
               File h=new File(out.getParent());
         files=h.listFiles(Imagefiles);
    
        view(out);
    
         }

        
           jMenuItem2.setEnabled(true);
           jMenuItem4.setVisible(true);
           jMenuItem3.setEnabled(true);
    jMenuItem10.setEnabled(true);
           
          
    }//GEN-LAST:event_jMenuItem1ActionPerformed
 BufferedImage img2;
 BufferedImage img1;
 
 
 
 //**********************************************************************
 public int[][] convert(BufferedImage image) {

       byte[] pix = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
       width = image.getWidth();
       height = image.getHeight();
     
      int[][] result = new int[height][width];
         final int pixelLength = 4;
         for (int pixel = 0, row = 0, col = 0; pixel < pix.length; pixel += pixelLength) {
            int argb = 0;
            argb += (((int) pix[pixel] & 0xff) << 24); // alpha
            argb += ((int) pix[pixel + 1] & 0xff); // blue
            argb += (((int) pix[pixel + 2] & 0xff) << 8); // green
            argb += (((int) pix[pixel + 3] & 0xff) << 16); // red
            result[row][col] = argb;
            col++;
            if (col == width) {
               col = 0;
               row++;
            }
         }
       

      return result;
   }
 
 //*****************************************************************************
 
 int m=0;
 public void show(BufferedImage as)
 {    
  int width=as.getWidth();
   int height=as.getHeight();
      if((height>jPanel2.getHeight())||(width>jPanel2.getWidth()))
  {float facty=(float)height/jPanel2.getHeight();
  float factx=(float)width/jPanel2.getWidth();
  float fact=(facty>factx)?facty:factx;
  height=(int)((int)height/fact);
  width=(int)((int)width/fact);
  }
     BufferedImage  i=new BufferedImage(width,height, BufferedImage.TYPE_4BYTE_ABGR);

            Graphics g1=i.createGraphics();
       g1.drawImage(as,0, 0,width,height,this);
       g1.dispose();   
  ImageIcon ic2=new ImageIcon(i);
 
 label3.setIcon(ic2); 
       label3.setHorizontalAlignment(JLabel.CENTER);
 }
 
    public void view(File a)
    {
        jSlider1.setValue(0);
jSlider2.setValue(0);
invert=0;
        MediaTracker mt=new MediaTracker(this);
        try
        {
            img= ImageIO.read(a);
        mt.addImage(img,0);
       
            mt.waitForAll();
        }
         catch(IOException | InterruptedException e)
        {
            System.out.println(e.getLocalizedMessage());
        }
   width=img.getWidth();
   height=img.getHeight();
   //*********************
  m=0;
  n=0;
   img1=new BufferedImage(label1.getWidth(), label1.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
   Graphics g=img1.createGraphics();
   g.drawImage(img,0, 0, label1.getWidth(),label1.getHeight(),this);
   g.dispose();
   ImageIcon ic=new ImageIcon(img1);
  
  if((height>jPanel2.getHeight())||(width>jPanel2.getWidth()))
  {float facty=(float)height/jPanel2.getHeight();
  float factx=(float)width/jPanel2.getWidth();
  float fact=(facty>factx)?facty:factx;
  height=(int)((int)height/fact);
  width=(int)((int)width/fact);
  }
   //*****************************************************************
  img2=new BufferedImage(width, height,BufferedImage.TYPE_4BYTE_ABGR);
       Graphics g1=img2.createGraphics();
       g1.drawImage(img,0, 0,width,height,this);
       g1.dispose();   
  show(img2);

  label1.setIcon(ic);
       
        pixels=new int[height][width]; 
        pixels=convert(img2);
  }
   //**************************************************************************************
         FilenameFilter Imagefiles=new FilenameFilter() {

            @Override
            public boolean accept(File dir, String name) {
               return (name.toLowerCase().endsWith(".jpg")||name.toLowerCase().endsWith(".png")||name.toLowerCase().endsWith(".jpeg"));
            }
        };

   //***************************************************************************************** 
   
            
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
jSlider1.setValue(0);
jSlider2.setValue(0);
if(m!=0||app==1)
{
    try
    {
        ImageIO.write(img2,"jpg", files[i]);       
    }
    catch(IOException ec)
    {}
}
if(files[i]!=null)
{i--;
if(i>=0)
          {   view(files[i]);
          }
        else
          { i=files.length-1;
        view(files[i]);
          }
}
else
{
    JOptionPane.showMessageDialog(rootPane,"image not seleceted");
}

    }//GEN-LAST:event_jButton1ActionPerformed
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
jSlider1.setValue(0);
jSlider2.setValue(0);
if(m!=0||app==1)
{
    try
    {
        ImageIO.write(img2,"jpg", files[i]);       
    }
    catch(IOException ec)
    {}
}
     
if(files[i]!=null)
{i++;
       i=i%files.length ;
        view(files[i]);
      
        
}
    }//GEN-LAST:event_jButton2ActionPerformed
BufferedImage img3;
int n=0;
public void flip1()
{
    
    
  img2=new BufferedImage(height,width, BufferedImage.TYPE_4BYTE_ABGR);
   for(int i=0;i<height;i++)
         for(int j=0;j<width;j++)
     img2.setRGB(height-i-1,j, pixels[i][j]);
    
}

public void flip2()
{
    
  img2=new BufferedImage(width,height, BufferedImage.TYPE_4BYTE_ABGR);
   for(int i=0;i<height;i++)
         for(int j=0;j<width;j++)
     img2.setRGB(j,i, pixels[height-1-i][width-1-j]);

}

public void flip3()
{
      img2=new BufferedImage(height,width, BufferedImage.TYPE_4BYTE_ABGR);
   for(int i=0;i<height;i++)
         for(int j=0;j<width;j++)
     img2.setRGB(height-i-1,j, pixels[height-1-i][width-1-j]);


}
public void flip4()
{
      img2=new BufferedImage(width,height, BufferedImage.TYPE_4BYTE_ABGR);
 for(int i=0;i<height;i++)
         for(int j=0;j<width;j++)
     img2.setRGB(j,i, pixels[i][j]);


}
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
jButton13.setEnabled(true);    
       
m+=1;
if(m%4==1)
{
 flip1();
}
else if(m%4==2)
{
 flip2();
}
else if(m%4==3)
{
flip3(); 
}
else
{
flip4(); 
}
     show(img2);

    }//GEN-LAST:event_jButton4ActionPerformed
 
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed




    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
jButton13.setEnabled(true);
        m+=1;
if(m%4==1)
{
    flip3();
}
else if(m%4==2)
{
    flip2();
}
else if(m%4==3)
{
    flip1();
    
}
else
{
    flip4();
}
 show(img2);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTree1TreeCollapsed(javax.swing.event.TreeExpansionEvent evt) {//GEN-FIRST:event_jTree1TreeCollapsed
    }//GEN-LAST:event_jTree1TreeCollapsed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

    }//GEN-LAST:event_jButton8ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
log l=new log();

l.setVisible(true);





    }//GEN-LAST:event_jMenuItem8ActionPerformed

        
    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
new register(this,true).setVisible(true);

    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        JColorChooser jcc=new JColorChooser(Color.BLACK);
        jPanel2.paintComponents(null);


    }//GEN-LAST:event_jButton9ActionPerformed

int app=0;    
    
    
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
app=1;
        jSlider1.setValue(0);
        jSlider2.setValue(0);
        if(m%2==0)
        { 
        newpixel=new int[height][width];
        for(int i=0;i<height;i++)
        {
            for(int j=0;j<width;j++)
            {
             newpixel[i][j]=pixels[i][j];
             pixels[i][j]=img2.getRGB(j, i);
            }
        }
        }
        else
       { 
        newpixel=new int[width][height];
        for(int i=0;i<width;i++)
        {
            for(int j=0;j<height;j++)
            {
             newpixel[i][j]=pixels[j][i];
             pixels[j][i]=img2.getRGB(j, i);
            }
        }
        }
      
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
jMenuItem2.setEnabled(false);
           jMenuItem3.setEnabled(false);
    jMenuItem4.setVisible(false);       
        files[i].delete();
        
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
rename r=new rename(this, true);
r.setVisible(true);
files[i].renameTo(new File(out.getParent(),r.name()));
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
try
{
        ImageIO.write(img2,"jpg", files[i]);       
}
catch(IOException ec)
{}
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
JFileChooser j=new JFileChooser(files[i].getParentFile());
int savevalue=j.showSaveDialog(this);
 
if ( savevalue == JFileChooser.APPROVE_OPTION) {
            try {
                ImageIO.write(img2, "png", new File(j.getSelectedFile().getAbsolutePath()));
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
jButton13.setEnabled(true);
invert++;

  img2=new BufferedImage(width,height, BufferedImage.TYPE_4BYTE_ABGR);
   for(int i=0;i<height;i++)
         for(int j=0;j<width;j++)
         {
             if(invert%2==1)
             {
                 img2.setRGB(j,i, pixels[height-1-i][j]);
             }
             else
             {
                 img2.setRGB(j,i,pixels[i][j]);
             }
         }

   show(img2);

    }//GEN-LAST:event_jButton12ActionPerformed

    private void jSlider1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider1StateChanged
jButton13.setEnabled(true);
jSlider2.setValue(0);
        if(jSlider1.getValue()!=0)
{  int a=(int)(jSlider1.getValue()*1.3);
    img2=new BufferedImage(width,height, BufferedImage.TYPE_3BYTE_BGR);
 newpixel =new int [height][width];
    for(int i=0;i<width;i++)
    {
        for(int j=0;j<height;j++)
        {
            newpixel[j][i]=pixels[j][i];
        }
    }
    for(int i=0;i<width;i++)
    {
        for(int j=0;j<height;j++)
        {int p=pixels[j][i];
            int alpha =truncate(((p>>24)&0xff)+a);
            int red=truncate(((p>>16)&0xff)+a);
            int green=truncate(((p>>8)&0xff)+a);
            int blue=truncate((p&0xff)+a);
            p=((alpha<<24)|(red<<16)|(green<<8)|blue);
            newpixel[j][i]=p;
        }
    }
    for( int i=0;i<height;i++)
         for(int j=0;j<width;j++)
     img2.setRGB(j,i, newpixel[i][j]);
 show(img2);
}
    }//GEN-LAST:event_jSlider1StateChanged

    private void jSlider1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jSlider1MouseExited
    }//GEN-LAST:event_jSlider1MouseExited

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed

        jSlider1.setValue(0);
jSlider2.setValue(0);


view(files[i]);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void label3MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_label3MouseWheelMoved




    }//GEN-LAST:event_label3MouseWheelMoved
int truncate(int n)
{
    if(n<0)
    {
        return 0;
    }
   else  if(n>255)
        return 255;
    else 
        return n;
}
    private void jSlider2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider2StateChanged
jButton13.setEnabled(true);
jSlider1.setValue(0);
if(jSlider2.getValue()!=0)
{  float a=(float)(jSlider2.getValue()+80)/50;
    img2=new BufferedImage(width,height, BufferedImage.TYPE_3BYTE_BGR);
 newpixel =new int [height][width];
    for(int i=0;i<width;i++)
    {
        for(int j=0;j<height;j++)
        {
            newpixel[j][i]=pixels[j][i];
        }
    }
    for(int i=0;i<width;i++)
    {
        for(int j=0;j<height;j++)
        {int p=pixels[j][i];
           int alpha =truncate((int)((((p>>24)&0xff)-128)*a)+128);
            int red=truncate((int)((((p>>16)&0xff)-128)*a)+128);
            int green=truncate((int)((((p>>8)&0xff)-128)*a)+128);
            int blue=truncate((int)((((p)&0xff)-128)*a)+128);
            p=(alpha<<24)|(red<<16)|(green<<8)|(blue);
            newpixel[j][i]=p;
        }
    }
    for( int i=0;i<height;i++)
         for(int j=0;j<width;j++)
     img2.setRGB(j,i, newpixel[i][j]);
 show(img2);

}       
        
    }//GEN-LAST:event_jSlider2StateChanged

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed

        jSlider1.setValue(0);
        jSlider2.setValue(0);
          
        if(m%2==0)
        { 
        
        for( int i=0;i<height;i++)
         for(int j=0;j<width;j++)
            img2.setRGB(j,i, newpixel[i][j]);
        }
        else
        {
         
        for( int i=0;i<width;i++)
         for(int j=0;j<height;j++)
            img2.setRGB(j,i, newpixel[i][j]);
           
        }
        
        show(img2);    
 jButton13.setEnabled(false);// TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JSlider jSlider2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar2;
    private javax.swing.JTree jTree1;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
    // End of variables declaration//GEN-END:variables
}

